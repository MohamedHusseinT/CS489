﻿namespace CAMS.Shared;

public class Class1
{

}
