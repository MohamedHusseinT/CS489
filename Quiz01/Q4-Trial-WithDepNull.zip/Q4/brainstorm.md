
HR staff view list of all department with all the Employees

company directors --> view the list of all Heads of each Department

system users --> see the total amount, in dollars and cents, being paid in salaries for the entire workforce in the company, annually.

-----
A Department will have many Employees. And each Employee works in one and only one Department

Also, each Department will have one Employee who serves as the Head of Department.

some Department(s) may NOT have Head of Department








