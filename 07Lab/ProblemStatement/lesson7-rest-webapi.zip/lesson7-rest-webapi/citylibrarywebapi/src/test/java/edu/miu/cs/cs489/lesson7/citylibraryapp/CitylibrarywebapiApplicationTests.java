package edu.miu.cs.cs489.lesson7.citylibraryapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CitylibrarywebapiApplicationTests {

    @Test
    void contextLoads() {
    }

}
