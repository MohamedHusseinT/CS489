package edu.miu.cs.cs489.lesson7.citylibraryapp.dto.publisher;

public record PublisherResponse2(
        Integer publisherId,
        String name
) {
}
