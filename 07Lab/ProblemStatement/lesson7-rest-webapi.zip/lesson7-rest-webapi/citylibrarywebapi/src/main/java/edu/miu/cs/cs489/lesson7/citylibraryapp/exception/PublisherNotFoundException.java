package edu.miu.cs.cs489.lesson7.citylibraryapp.exception;

public class PublisherNotFoundException extends Exception {

    public PublisherNotFoundException(String message) {
        super(message);
    }

}
