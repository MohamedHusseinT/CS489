package edu.miu.cs.cs489.lesson6.citylibraryapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CitylibrarycliappApplicationTests {

    @Test
    void contextLoads() {
    }

}
