Property managers is to be able to view 
-the list of all Leases for Properties that they own/manage
-Projected total Revenue (income) that accrues from the Leases.

